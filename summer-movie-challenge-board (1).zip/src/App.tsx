/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Film, KanbanSquare, Settings, Play, Award, Loader2 } from 'lucide-react';
import { AnimatePresence } from 'motion/react';
import { ChallengeConfig, MovieTopic } from './types';
import AdminConfig from './components/AdminConfig';
import ChallengeBoard from './components/ChallengeBoard';
import TopicDetailsModal from './components/TopicDetailsModal';
import InteractiveRevealer from './components/InteractiveRevealer';

import { doc, collection, onSnapshot, setDoc, deleteDoc } from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from './lib/firebase';

const LOCAL_STORAGE_KEY = 'summer_movie_challenge_config';

export default function App() {
  const [challengeDoc, setChallengeDoc] = useState<{ challengeTitle: string; creatorName: string } | null>(null);
  const [topics, setTopics] = useState<MovieTopic[]>([]);
  const [loading, setLoading] = useState(true);

  const [mode, setMode] = useState<'board' | 'creator'>('board');
  const [showAdminAccess, setShowAdminAccess] = useState(false);
  const [activeRevealTopic, setActiveRevealTopic] = useState<MovieTopic | null>(null);
  const [activeEditTopic, setActiveEditTopic] = useState<MovieTopic | null>(null);

  const [localRevealedIds, setLocalRevealedIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('local_revealed_topics');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [confirmReset, setConfirmReset] = useState(false);

  const seedingInProgress = useRef(false);

  // Check URL query parameters or hashes to unlock Admin/Organizer access
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const hasAdminParam = params.get('admin') === 'true' || params.get('organizer') === 'true' || params.has('secret');
    const hasAdminHash = window.location.hash === '#admin' || window.location.hash === '#creator' || window.location.hash === '#secret';
    const hasLocalStore = localStorage.getItem('movie_challenge_admin') === 'true';

    if (hasAdminParam || hasAdminHash || hasLocalStore) {
      setShowAdminAccess(true);
      // Persist access so they can refresh pages cleanly
      localStorage.setItem('movie_challenge_admin', 'true');
      
      // If they accessed directly with a parameter or hash, boot directly into creator mode
      if (hasAdminParam || hasAdminHash) {
        setMode('creator');
      }
    }
  }, []);

  const handleExitAdminAccess = () => {
    localStorage.removeItem('movie_challenge_admin');
    setShowAdminAccess(false);
    setMode('board');
  };

  // Sync with Firestore in real-time
  useEffect(() => {
    const unsubChallenge = onSnapshot(
      doc(db, "challenges", "default"),
      async (snapshot) => {
        if (snapshot.exists()) {
          setChallengeDoc(snapshot.data() as { challengeTitle: string; creatorName: string });
        }
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, "challenges/default");
      }
    );

    const unsubTopics = onSnapshot(
      collection(db, "challenges", "default", "topics"),
      async (snapshot) => {
        const loadedTopics: MovieTopic[] = [];
        snapshot.forEach((docSnap) => {
          loadedTopics.push(docSnap.data() as MovieTopic);
        });

        // Sort topics by id ascending
        loadedTopics.sort((a, b) => a.id - b.id);

        setTopics(loadedTopics);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, "challenges/default/topics");
      }
    );

    return () => {
      unsubChallenge();
      unsubTopics();
    };
  }, []);

  // Formulate reactive config object driven entirely by real-time Firestore data
  const config: ChallengeConfig = {
    challengeTitle: challengeDoc?.challengeTitle || "5-й Ежегодный Летний Киночеллендж Комитета",
    creatorName: challengeDoc?.creatorName || "Комитет",
    topics: topics.map((t) => ({
      ...t,
      isRevealedByUser: localRevealedIds.includes(t.id),
    })),
  };

  // Update whole config state - syncing delta to Firestore
  const handleUpdateConfig = async (newConfig: ChallengeConfig) => {
    try {
      // 1. Sync metadata
      const docRef = doc(db, "challenges", "default");
      await setDoc(docRef, {
        challengeTitle: newConfig.challengeTitle,
        creatorName: newConfig.creatorName,
      }, { merge: true });

      // 2. Perform delta updates of topics collection to save read/write quotas
      const currentTopicsMap = new Map(topics.map(t => [t.id, t]));
      const newTopicsMap = new Map(newConfig.topics.map(t => [t.id, t]));

      // Delete removed ones
      for (const oldTopic of topics) {
        if (!newTopicsMap.has(oldTopic.id)) {
          await deleteDoc(doc(db, "challenges/default/topics", `topic_${oldTopic.id}`));
        }
      }

      // Add or update new/modified ones
      for (const newTopic of newConfig.topics) {
        const oldTopic = currentTopicsMap.get(newTopic.id);
        if (!oldTopic || JSON.stringify(oldTopic) !== JSON.stringify(newTopic)) {
          await setDoc(doc(db, "challenges/default/topics", `topic_${newTopic.id}`), newTopic);
        }
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, "challenges/default");
    }
  };

  // Update single topic fields directly in Firestore
  const handleUpdateTopic = async (topicId: number, updatedFields: Partial<MovieTopic>) => {
    try {
      const topicRef = doc(db, "challenges/default/topics", `topic_${topicId}`);
      await setDoc(topicRef, updatedFields, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `challenges/default/topics/topic_${topicId}`);
    }
  };

  // Launch animation trigger
  const handleTriggerReveal = (topic: MovieTopic) => {
    setActiveRevealTopic(topic);
  };

  // Finished scratch / pop animation -> save unlocked state
  const handleRevealComplete = () => {
    if (activeRevealTopic) {
      setLocalRevealedIds(prev => {
        const next = [...prev];
        if (!next.includes(activeRevealTopic.id)) {
          next.push(activeRevealTopic.id);
        }
        localStorage.setItem('local_revealed_topics', JSON.stringify(next));
        return next;
      });
      setActiveRevealTopic(null);
    }
  };

  // Click single square edit handler
  const handleEditSlot = (id: number) => {
    const target = config.topics.find((t) => t.id === id);
    if (target) {
      setActiveEditTopic(target);
    }
  };

  // Save single square details modal edit
  const handleSaveDetails = (updatedFields: Partial<MovieTopic>) => {
    if (activeEditTopic) {
      handleUpdateTopic(activeEditTopic.id, updatedFields);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-vibrant-yellow text-black font-sans flex flex-col items-center justify-center p-4">
        <div className="bg-white border-4 border-black rounded-3xl p-8 max-w-sm w-full text-center shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col items-center space-y-4">
          <Loader2 className="w-12 h-12 text-vibrant-pink animate-spin" />
          <h2 className="text-xl font-display font-black uppercase text-black leading-tight">СИНХРОНИЗАЦИЯ...</h2>
          <p className="text-xs text-gray-700 font-bold leading-relaxed">
            Подключаемся к базе данных реального времени, чтобы отобразить самые свежие обновления проекта!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-vibrant-yellow text-black font-sans flex flex-col justify-between p-4 sm:p-6 md:p-8">
      {/* Main App Navigation Wrapper */}
      <header className="sticky top-0 z-30 bg-white border-4 border-black rounded-3xl p-4 sm:p-5 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] max-w-7xl w-full mx-auto mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Logo / Brand Name */}
        <div className="flex items-center gap-4 select-none">
          <div className="bg-vibrant-pink p-3 rounded-2xl transform -rotate-3 border-2 border-black flex items-center justify-center text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            <span className="text-xl">🎬</span>
          </div>
          <div>
            <span className="font-display font-black text-xl sm:text-2xl tracking-tighter text-black uppercase block leading-none">
              5-й Летний Киночеллендж Комитета
            </span>
          </div>
        </div>

        {/* Nav controller options selection */}
        {showAdminAccess && (
          <div className="flex items-center bg-white border-2 border-black p-1 rounded-xl gap-1">
            <button
              onClick={() => setMode('board')}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                mode === 'board'
                  ? 'bg-vibrant-pink text-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  : 'text-black hover:bg-gray-100'
              }`}
              id="nav-board-mode-btn"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Доска Челленджа</span>
            </button>
            <button
              onClick={() => setMode('creator')}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                mode === 'creator'
                  ? 'bg-vibrant-pink text-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  : 'text-black hover:bg-gray-100'
              }`}
              id="nav-creator-mode-btn"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Панель Организатора</span>
            </button>
          </div>
        )}

      </header>

      {/* Primary body screen switcher */}
      <main className="flex-1 w-full max-w-7xl mx-auto relative">
        {mode === 'creator' && showAdminAccess ? (
          <AdminConfig
            config={config}
            onUpdateConfig={handleUpdateConfig}
            onEditSlot={handleEditSlot}
            onViewBoard={() => setMode('board')}
            onExitAdminAccess={handleExitAdminAccess}
          />
        ) : (
          <ChallengeBoard
            config={config}
            onUpdateTopic={handleUpdateTopic}
            onTriggerReveal={handleTriggerReveal}
            onGoBackToWorkspace={() => setMode('creator')}
            showAdminAccess={showAdminAccess}
          />
        )}
      </main>

      {/* Global Modals Portal Container */}
      <AnimatePresence>
        {/* Modal A: Interactive topic microgames animations */}
        {activeRevealTopic && (
          <InteractiveRevealer
            topic={activeRevealTopic}
            onRevealComplete={handleRevealComplete}
            onClose={() => setActiveRevealTopic(null)}
          />
        )}

        {/* Modal B: Individual topic slot settings editor */}
        {activeEditTopic && (
          <TopicDetailsModal
            topic={activeEditTopic}
            onSave={handleSaveDetails}
            onClose={() => setActiveEditTopic(null)}
            onDelete={(id) => {
              handleUpdateConfig({
                ...config,
                topics: config.topics.filter(t => t.id !== id)
              });
              setActiveEditTopic(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Tiny descriptive subtle footer resembling design theme */}
      <footer className="w-full max-w-7xl mx-auto mt-8 pt-4 border-t-2 border-black flex flex-col md:flex-row justify-between items-center text-xs font-black uppercase text-black gap-4">
        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-4 h-4 bg-vibrant-lime border-2 border-black rounded-full"></span>
            <span>Раскрыто тем: {config.topics.filter(t => t.isRevealedByUser).length}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-4 bg-white border-2 border-black border-dashed rounded-full"></span>
            <span>Заблокировано тем: {config.topics.filter(t => !t.isRevealedByUser).length}</span>
          </div>
          {localRevealedIds.length > 0 && (
            <div className="relative">
              {!confirmReset ? (
                <button
                  onClick={() => setConfirmReset(true)}
                  className="px-2 py-1 bg-white border-2 border-black rounded-lg text-[9px] font-black uppercase tracking-wider text-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-0.5 transition-all cursor-pointer"
                  id="reset-my-progress-btn"
                >
                  🔄 Сбросить мои открытия
                </button>
              ) : (
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-vibrant-pink animate-pulse font-extrabold mr-1">Точно сбросить?</span>
                  <button
                    onClick={() => {
                      setLocalRevealedIds([]);
                      localStorage.setItem('local_revealed_topics', JSON.stringify([]));
                      setConfirmReset(false);
                    }}
                    className="px-2 py-1 bg-red-400 hover:bg-red-500 border-2 border-black rounded-lg text-[9px] font-black uppercase tracking-wider text-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5 transition-all cursor-pointer"
                    id="reset-my-progress-confirm-btn"
                  >
                    Да
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="px-2 py-1 bg-gray-200 hover:bg-gray-300 border-2 border-black rounded-lg text-[9px] font-black uppercase tracking-wider text-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5 transition-all cursor-pointer"
                    id="reset-my-progress-cancel-btn"
                  >
                    Нет
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        <div>
          СПЕЦИАЛЬНО ДЛЯ ЧЛЕНОВ КОМИТЕТА v5.0
        </div>
      </footer>

    </div>
  );
}
